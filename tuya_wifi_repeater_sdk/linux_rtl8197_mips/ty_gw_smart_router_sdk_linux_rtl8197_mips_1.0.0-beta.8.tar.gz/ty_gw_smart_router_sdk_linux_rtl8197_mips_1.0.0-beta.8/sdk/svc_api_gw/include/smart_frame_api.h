/***********************************************************
*  File: smart_frame_api.h
*  Author: wsj
*  Date: 20200901
***********************************************************/
#ifndef _SMART_FRAME_API_H
#define _SMART_FRAME_API_H

#include "gw_intf.h"

#ifdef __cplusplus
    extern "C" {
#endif
/***********************************************************
*  Function: gw_sf_dp_data_get
*  Input:  CHAR_T *id, CHAR_T dp_id
*  Output: none
*  Return: DP_CNTL_S
***********************************************************/
DP_CNTL_S * gw_sf_dp_data_get(IN CONST CHAR_T *id, IN CONST CHAR_T dp_id);

/***********************************************************
*  Function: gw_sf_dp_data_is_equl
*  Input: dp_cmd
*  Output: none
*  Return: bool
***********************************************************/
BOOL_T gw_sf_dp_data_is_equl(IN ty_cJSON *dp_cmd);

#ifdef __cplusplus
}
#endif
#endif


