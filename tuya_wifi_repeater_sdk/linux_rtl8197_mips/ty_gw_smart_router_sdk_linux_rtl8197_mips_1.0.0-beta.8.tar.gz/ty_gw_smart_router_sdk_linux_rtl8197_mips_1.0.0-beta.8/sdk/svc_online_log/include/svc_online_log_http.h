/**
 * @file online_log_serv.c
 * @author nzy
 * @brief log上传服务
 * @version 0.1
 * @date 2019-08-29
 * 
 * @copyright Copyright (c) 2019
 * 
 */
#ifndef __SVC_ONLINE_LOG_HTTP_H__
#define __SVC_ONLINE_LOG_HTTP_H__

#ifdef __cplusplus
extern "C" {
#endif

int online_log_http_property_save(char *env_data);


#ifdef __cplusplus
}
#endif
#endif



