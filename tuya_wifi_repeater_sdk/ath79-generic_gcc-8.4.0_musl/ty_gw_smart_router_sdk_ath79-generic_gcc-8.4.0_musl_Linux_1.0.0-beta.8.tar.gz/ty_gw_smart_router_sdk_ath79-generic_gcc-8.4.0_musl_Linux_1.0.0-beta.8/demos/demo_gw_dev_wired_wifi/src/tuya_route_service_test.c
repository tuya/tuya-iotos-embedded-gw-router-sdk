#include "tuya_cloud_types.h"
#include "tuya_cloud_error_code.h"
#include "tuya_cloud_com_defs.h"
#include "tuya_iot_com_api.h"
#include "uni_log.h"

#include "tuya_cloud_base_defs.h"
#include "tuya_iot_base_api.h"

#include <stdio.h>
#include <unistd.h>
#include <string.h>

#include "tuya_svc_route.h"

BOOL_T route_allow = 1; 
BOOL_T route_limit = 1;
UINT_T route_up_limit = 10;
UINT_T route_down_limit = 20;

#define STA_DPID (15)//115

VOID ty_route_sta_cmd_cb(IN CONST TY_ROUTE_STA_CMD_E cmd, IN CONST CHAR_T *mac, 
                                    IN CONST UINT_T value)
{
    TUYA_ROUTE_STA_CONF_S config = {0x0};

    PR_DEBUG("cmd:%d mac:%s value:%d\n", cmd, mac, value);
    switch (cmd) {
        case TY_STA_CMD_ALLOW_NET:     
            route_allow = value;
            tuya_route_rept_sta_allow_net(mac, route_allow, STA_DPID);
            break;

        case TY_STA_CMD_SPEED_LIMIT:     
            route_limit = value;
            tuya_route_rept_sta_limit(mac, route_limit, STA_DPID);
            break;

        case TY_STA_CMD_UP_LIMIT:     
            route_up_limit = value;
            tuya_route_rept_sta_up_limit(mac, route_up_limit, STA_DPID);
            break;

        case TY_STA_CMD_DOWN_LIMIT:     
            route_down_limit = value;
            tuya_route_rept_sta_down_limit(mac, route_down_limit, STA_DPID);
            break;

        case TY_STA_CMD_GET_ALL_CONFIG:     
            config.allow = route_allow;
            config.limit = route_limit;
            config.up_limit = route_up_limit;
            config.down_limit = route_down_limit;
            tuya_route_rept_sta_all(mac, &config, STA_DPID);
            break;

        default:
            break;

    }
}

VOID ty_route_cmd_handle_cb(IN CONST TY_ROUTE_CMD_E cmd)
{
    TUYA_ROUTE_WIFI_LIST_S wifi_list[3] = {0x0};
    TUYA_ROUTE_DEV_LIST_S dev_list[2] = {0x0};

    switch (cmd) {
        case TY_ROUTE_CMD_GET_WIFI_LIST:
            strcpy(wifi_list[0].ssid, "netcore");
            wifi_list[0].b_encrypted = TRUE;
            wifi_list[0].signal_strength = TY_WIFI_SIG_HIGH;
            strcpy(wifi_list[1].ssid, "HUA-SAN");
            wifi_list[1].b_encrypted = TRUE;
            wifi_list[1].signal_strength = TY_WIFI_SIG_LOW;
            strcpy(wifi_list[2].ssid, "HUA-WEI");
            wifi_list[2].b_encrypted = TRUE;
            wifi_list[2].signal_strength = TY_WIFI_SIG_HIGH;
            tuya_route_rept_wifi_list(3, wifi_list);
            break;

        case TY_ROUTE_CMD_GET_ONLINE_LIST:
            strcpy(dev_list[0].dev_name, "ty_wifi_dev");
            strcpy(dev_list[0].mac, "11:22:33:44:55:66");
            dev_list[0].wifi_types = TY_WIFI_TYPE_2_4G;
            strcpy(dev_list[1].dev_name, "iphone2");
            strcpy(dev_list[1].mac, "77:22:33:44:55:66");
            dev_list[1].wifi_types = TY_WIFI_TYPE_5G;
            tuya_route_rept_online_list(2, dev_list);
            break;

        default :
            break;
    }
}

CHAR_T u_ssid[56] = {0};
CHAR_T u_password[56] = {0};
VOID ty_route_get_source_cb(VOID)
{
    //CONST CHAR_T *ssid = "routerName";
    //CONST CHAR_T *pwd = "123456";

    PR_DEBUG("ssid:%s, pwd:%s", u_ssid, u_password);
    tuya_route_rept_source(u_ssid, u_password);
}

VOID ty_route_set_source_cb(IN CONST CHAR_T *ssid, IN CONST CHAR_T *pwd)
{
    if (NULL == ssid || NULL == pwd) {
        PR_ERR("Paramater is invalid.");
        return ;
    }

    if (0 != strlen(ssid))
        PR_DEBUG("ssid:%s", ssid);
    if (0 != strlen(pwd))
        PR_DEBUG("pwd:%s", pwd);

    strcpy(u_ssid, ssid);
    strcpy(u_password, pwd);
    tuya_route_rept_source(ssid, pwd);
}

TUYA_ROUTE_HOTSPOT_S hotspot[2] = {
    {TY_WIFI_TYPE_2_4G, "huasan-2.4G", "123456"},
    {TY_WIFI_TYPE_5G, "huasan-5G", "123456"},
};
BOOL_T password_set = FALSE;

VOID ty_route_get_hotspot_cb(VOID)
{
/*
    TUYA_ROUTE_HOTSPOT_S hotspot[2] = {
        {TY_WIFI_TYPE_2_4G, "huasan-2.4G", "123456"},
        {TY_WIFI_TYPE_5G, "huasan-5G", "123456"},
    };
*/
    tuya_route_rept_hotspot(hotspot, CNTSOF(hotspot));
}

VOID ty_route_set_hotspot_cb(IN CONST TUYA_ROUTE_HOTSPOT_S *p_hotspot, IN CONST USHORT_T num)
{
    USHORT_T i = 0;
    if (NULL == p_hotspot || 0 == num) {
        PR_ERR("Paramater is invalid.");
        return ;
    }

    for (i = 0; i < num; i++) {
        PR_DEBUG("wifi_typess: %d, sid:%s, pwd:%s", \
            p_hotspot[i].wifi_types, p_hotspot[i].ssid, p_hotspot[i].pwd);
        hotspot[i].wifi_types = p_hotspot[i].wifi_types;
        strcpy(hotspot[i].ssid, p_hotspot[i].ssid);
        strcpy(hotspot[i].pwd, p_hotspot[i].pwd);
    }

    tuya_route_rept_hotspot(hotspot, CNTSOF(hotspot));
    password_set = TRUE;

    demo_is_password_set(password_set);
}

STATIC CHAR_T route_pwd[2][20] = {"123456", "abcdef"};
VOID ty_route_query_pwd_cb(IN CONST TUYA_ROUTE_PWD_E type)
{
    if (TY_ROUTE_PWD_INVALID == type ) {
        PR_ERR("invalid param");
        return ;
    }
    INT_T i = (INT_T)type - 1;
    PR_DEBUG("type:%d, pwd:%s", (INT_T)type, route_pwd[i]);
    tuya_route_rept_pwd(type, route_pwd[i]);
}

VOID ty_route_set_pwd_cb(IN CONST TUYA_ROUTE_PWD_E type, IN CONST CHAR_T *pwd)
{
    if (TY_ROUTE_PWD_INVALID == type ) {
        PR_ERR("invalid param");
        return ;
    }
    INT_T i = (INT_T)type - 1;
    PR_DEBUG("type:%d, pwd:%s", (INT_T)type, pwd);
    snprintf(route_pwd[i], sizeof(route_pwd[i]), "%s", pwd);
    ty_route_query_pwd_cb(type);
}


VOID demo_is_password_set(BOOL_T set)
{
    TY_OBJ_DP_S dp_data = {0};

    dp_data.value.dp_bool= set;
    dp_data.dpid = 8;
    dp_data.type = PROP_BOOL;
    dp_data.time_stamp = 0;

    dev_report_dp_json_async(NULL, &dp_data, 1);
}

OPERATE_RET tuya_route_test_start(VOID)
{
    OPERATE_RET op_ret = OPRT_OK;
    TUYA_ROUTE_CBS_S route_cbs = {
        .cmd_handle_cb      =   ty_route_cmd_handle_cb,
        .get_source_cb      =   ty_route_get_source_cb,
        .set_source_cb      =   ty_route_set_source_cb,
        .get_hotspot_cb     =   ty_route_get_hotspot_cb,
        .set_hotspot_cb     =   ty_route_set_hotspot_cb,
        .route_query_pwd_cb =   ty_route_query_pwd_cb,
        .route_set_pwd_cb   =   ty_route_set_pwd_cb,
    };

    TUYA_ROUTE_STA_CBS_S sta_cbs = {
        .sta_cmd_cb =       ty_route_sta_cmd_cb
    };

    op_ret = tuya_route_service_init(&route_cbs, &sta_cbs);
    if (op_ret != OPRT_OK) {
        PR_ERR("tuya_route_service_init faild, [%d]", op_ret);
    }

    sleep(1);
    TUYA_ROUTE_DEV_LIST_S list[2] = {0x0};
    strcpy(list[0].dev_name, "iphone");
    strcpy(list[0].mac, "11:22:33:44:55:66");
    list[0].wifi_types = TY_WIFI_TYPE_2_4G;

    strcpy(list[1].dev_name, "iphone2");
    strcpy(list[1].mac, "77:22:33:44:55:66");
    list[1].wifi_types = TY_WIFI_TYPE_5G;
    op_ret = tuya_route_rept_online_list(2, list);
    if (op_ret != OPRT_OK) {
        PR_ERR("tuya_route_rept_online_list faild, [%d]", op_ret);
    }

    /*上报wifi中继器连接的路由器的wifi名和密码*/
    op_ret = tuya_route_rept_source("routerName", "123456");
    if (op_ret != OPRT_OK) {
        PR_ERR("tuya_route_rept_source faild, [%d]", op_ret);
    }
    op_ret = tuya_route_rept_sta_allow_net("11:22:33:44:55:66", 1, STA_DPID);
    if (op_ret != OPRT_OK) {
        PR_ERR("tuya_route_rept_sta_allow_net faild, [%d]", op_ret);
    }
    op_ret = tuya_route_rept_sta_up_limit("11:22:33:44:55:66", 100, STA_DPID);
    if (op_ret != OPRT_OK) {
        PR_ERR("tuya_route_rept_sta_up_limit faild, [%d]", op_ret);
    }

    TUYA_ROUTE_STA_CONF_S config = {0x0};
    config.allow = route_allow;
    config.limit = route_limit;
    config.up_limit = route_up_limit;
    config.down_limit = route_down_limit;
    op_ret = tuya_route_rept_sta_all("11:22:33:44:55:66", &config, STA_DPID);
    if (op_ret != OPRT_OK) {
        PR_ERR("tuya_route_rept_sta_all faild, [%d]", op_ret);
    }

    op_ret = tuya_route_sta_data_parse("{\"mac\":\"11:22:33:44:55:66\",\"maxUpSpeed\":10}");
    if (op_ret != OPRT_OK) {
        PR_ERR("tuya_route_sta_data_parse faild, [%d]", op_ret);
    }

    return OPRT_OK;
}
