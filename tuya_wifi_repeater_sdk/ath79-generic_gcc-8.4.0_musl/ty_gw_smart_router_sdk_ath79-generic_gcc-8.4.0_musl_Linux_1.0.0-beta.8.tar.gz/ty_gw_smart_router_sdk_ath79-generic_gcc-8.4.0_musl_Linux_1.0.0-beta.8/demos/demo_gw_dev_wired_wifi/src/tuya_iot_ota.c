#include "tuya_hal_ota.h"
#include "tuya_cloud_types.h"
#include <string.h>
#include <stdbool.h>
#include "uni_log.h"

/***********************************************************
 *************************variable define********************
 ***********************************************************/

static int write_fota_upgrade_data(uint32_t block_num, uint8_t  block_more,
        uint8_t * data, uint16_t datalen)
{
    PR_DEBUG("===========>%s", __func__);

    return 0;
}

/**
 * @brief 升级开始通知函数
 *
 * @param[in] file_size 升级固件大小
 *
 * @retval  =0      成功
 * @retval  <0      错误码
 */
OPERATE_RET tuya_os_adapt_ota_start_inform(unsigned int file_size)
{
    PR_DEBUG("===========>%s", __func__);
    return OPRT_OS_ADAPTER_OK;
}

/**
 * @brief ota数据包处理
 *
 * @param[in] total_len ota升级包总大小
 * @param[in] offset 当前data在升级包中的偏移
 * @param[in] data ota数据buffer指针
 * @param[in] len ota数据buffer长度
 * @param[out] remain_len 内部已经下发但该函数还未处理的数据长度
 * @param[in] pri_data 保留参数
 *
 * @retval  =0      成功
 * @retval  <0      错误码
 */
OPERATE_RET tuya_os_adapt_ota_data_process(const unsigned int total_len, const unsigned int offset,
        const unsigned char* data, const unsigned int len, unsigned int* remain_len, void* pri_data)
{
    PR_DEBUG("===========>%s", __func__);

    return OPRT_OS_ADAPTER_OK;
}

/**
 * @brief 固件ota数据传输完毕通知
 *        用户可以做固件校验以及设备重启
 * param[in]        reset       是否需要重启
 * @retval  =0      成功
 * @retval  <0      错误码
 */
OPERATE_RET tuya_os_adapt_ota_end_inform(BOOL_T reset)
{
    PR_DEBUG("===========>%s", __func__);

    return OPRT_OS_ADAPTER_OK;
}

/* interface register */
static TUYA_OS_OTA_INTF m_tuya_os_ota_intfs = {
    .start      = tuya_os_adapt_ota_start_inform,
    .process    = tuya_os_adapt_ota_data_process,
    .end        = tuya_os_adapt_ota_end_inform,
};


/* interface register */
int tuya_os_adapt_reg_ota_intf(void)
{
    return tuya_os_adapt_reg_intf(INTF_OTA, &m_tuya_os_ota_intfs);
}
