#include "tuya_hal_wired.h"
#include "tuya_cloud_types.h"
#include <string.h>
#include <stdbool.h>
#include "uni_log.h"

INT_T user_hal_wired_get_ip(NW_IP_S *ip)
{
    strcpy(ip->ip, "192.168.10.152");
    PR_DEBUG("wired get ip: %s", ip->ip);
    return OPRT_OK;
}

BOOL_T user_hal_wired_station_conn(VOID)
{
    return TRUE;
}

INT_T user_hal_wired_get_mac(NW_MAC_S *mac)
{
    return OPRT_OK;
}

INT_T user_hal_wired_set_mac(CONST NW_MAC_S *mac)
{
    return OPRT_OK;
}

INT_T user_hal_wired_wifi_set_station_connect(CONST CHAR_T *ssid, CONST CHAR_T *passwd)
{
    return OPRT_OK;
}


BOOL_T user_hal_wired_wifi_need_cfg(VOID)
{
    return TRUE;
}

INT_T user_hal_wired_wifi_station_get_conn_ap_rssi(int8_t *rssi)
{
    *rssi = 99;
    return OPRT_OK;
}

INT_T user_hal_wired_get_nw_stat(GW_BASE_NW_STAT_T *stat)
{
    *stat = 1;
    return OPRT_OK;
}

INT_T tuya_hal_wired_if_connect_internet(BOOL_T *status)
{
    *status = TRUE;
    return OPRT_OK;
}


STATIC TUYA_OS_WIRED_INTF tuya_8197_wired_intfs = {
    .get_ip = user_hal_wired_get_ip,
    .get_mac = user_hal_wired_get_mac,
    .set_mac = user_hal_wired_set_mac,
    .set_station_connect = user_hal_wired_wifi_set_station_connect,
    .station_get_conn_ap_rssi =  user_hal_wired_wifi_station_get_conn_ap_rssi,
    .get_nw_stat = user_hal_wired_get_nw_stat,
    .if_connect_internet = tuya_hal_wired_if_connect_internet,
    .need_cfg = user_hal_wired_wifi_need_cfg,
    .station_conn = user_hal_wired_station_conn,
};

 OPERATE_RET tuya_register_wired_intf(void)
 {
     return tuya_os_adapt_reg_intf(INTF_WIRED, (void*)&tuya_8197_wired_intfs);
 }


