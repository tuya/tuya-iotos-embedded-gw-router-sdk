#include "tuya_cloud_types.h"
#include <stdio.h>
#include <stdlib.h>

#include <string.h>
#include <unistd.h>

#include <net/if.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/ioctl.h>
#include <stdio.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <errno.h>
#include <ctype.h>
#include <netinet/in.h>
#include <netinet/if_ether.h> 
#include <netinet/ether.h>

#include <pthread.h>
#include "tuya_os_adapter.h"
#include "uni_log.h"


/***********************************************************
*************************micro define***********************
***********************************************************/
#include <sys/wait.h>
#include <sys/time.h>
#include <sys/resource.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <fcntl.h>
#include <limits.h>
#include <stdarg.h>

STATIC VOID hwl_bnw_8197wlan_get_mode(BOOL_T *apmode);

static int exec_cmd (const char *format, ...)
{
#define MAX_CMD_BUF 128
	va_list vaList;
	char cmdBuff[MAX_CMD_BUF]={0};

	va_start (vaList, format);
	vsnprintf ((char *)cmdBuff, sizeof(cmdBuff), format, vaList);
	va_end (vaList);

	//PR_DEBUG("Exec Cmd:%s \r\n", cmdBuff);
	//return linux_exec_cmd((char *)cmdBuff,NULL,0);
    return system((char *)cmdBuff);
	// popen((char*)cmdBuff, "r");
	// return 0;
}


/***********************************************************
*************************function define********************
***********************************************************/
CHAR_T g_wifi_net_name[16] = {0};
VOID hwl_wf_set_net_interface_name(IN CONST CHAR_T *wifi_net_name)
{
    if(wifi_net_name)
        snprintf(g_wifi_net_name, 16, "%s", wifi_net_name);
}

#define WLAN_DEV            "wlx00367643995c"

#define WIFI_SSID_LEN 32    
#define WIFI_PASSWD_LEN 64

#define MAX_AP_SEARCH   (64)
#define MAX_R_BUF (128)

#define NETWORK_RESTART "init.sh ap all"

STATIC VOID exec_cmd_ary(CHAR_T (*ary)[MAX_R_BUF] , INT_T num)
{
    if(NULL == ary) {
        printf("cmd ary is empty\n");
        return;
    }
    
    int i;
    for(i = 0; i < num; i++) {
        if(ary[i]) {
            //printf("%s\n",ary[i]);
            //linux_exec_cmd(ary[i],NULL,0);
        }
    }
}

//增加判断，不然每次去连，效率低
STATIC BOOL_T tuya_8197_wifi_station_is_connect_ap(IN CONST CHAR_T *ssid,IN CONST CHAR_T *passwd)
{

}


// 使用指定SSID和PASSWD连接WIFI
OPERATE_RET tuya_8197_wifi_station_connect(IN CONST SCHAR_T *ssid,IN CONST SCHAR_T *passwd)
{
	return OPRT_OK;
}

OPERATE_RET tuya_8197_wifi_all_ap_scan(OUT AP_IF_S **ap_ary,OUT UINT_T *num)
{    
	return 0;
}


// 获取特定SSID的信息
OPERATE_RET tuya_8197_wifi_assign_ap_scan(CONST SCHAR_T *ssid,OUT AP_IF_S **ap)
{
    return OPRT_OK;
}

// 释放内存
OPERATE_RET tuya_8197_wifi_release_ap(IN AP_IF_S *ap)
{
    // s_aps为静态变量，无需释放
    return OPRT_OK;
}

// 设置WIFI的工作信道
OPERATE_RET tuya_8197_wifi_set_cur_channel(IN CONST BYTE_T chan)
{
	return OPRT_OK;
}

// 获取WIFI的工作信道
OPERATE_RET tuya_8197_wifi_get_cur_channel(OUT BYTE_T *chan)
{
    //PR_DEBUG("WIFI Get Curr Channel:%d", *chan);
    return OPRT_OK;    
}
#pragma pack(1)
/* http://www.radiotap.org/  */
typedef struct {
    BYTE_T it_version;
    BYTE_T it_pad;
    USHORT_T it_len;
    UINT_T it_present;
}ieee80211_radiotap_header;
#pragma pack()

static volatile SNIFFER_CALLBACK s_pSnifferCall = NULL;
static volatile int s_enable_sniffer = 0;
struct rtl_wifi_header{
	unsigned short 	pkt_len;
	unsigned short 	payload_len;
	unsigned char 	data[252];				
}__attribute__((packed));

typedef struct wlan_80211_frame {
    u_char frmae_ctl1;
    u_char frmae_ctl2;
    u_short duration;
    u_char addr1[6];    
    u_char addr2[6];    
    u_char addr3[6];
    u_short seq_ctl;
    u_char addr4[6];
}WLAN_80211_HEAD;

BOOL_T compare_wlan0_mac_equal(u_char *mac1,u_char *mac2)
{
    int i = 0;
    for(i = 0; i<6; i++) {
        if(mac1[i] != mac2[i])
            return 0;
    }
    return 1;
}

void print_wlan_mac(char *str,u_char *mac) {
    PR_DEBUG("=======%s %02x%02x%02x%02x%02x%02x",str,mac[0],mac[1],mac[2],mac[3],mac[4],mac[5]);
}

void prinf_wlan0_frame(u_char *buf,u_int len)
{
    PR_DEBUG("================FRAME BUF IS:");
    int i;
    for(i = 0; i < len; i++) {
        printf("%02x ",buf[i]);
    }
    printf("\n\n");
}

#define junzi_mac "\x9c\xa6\x15\xf0\xa2\xd9"
#define hxh_mac "\x20\xf4\x1b\x83\xea\xf6"
#define xb_mac "\x00\xe0\x4c\x81\x96\xc1"
static void parse_80211packet(u_char *buf , u_int len)
{
    //prinf_wlan0_frame(buf,len);
    WLAN_80211_HEAD *wbuf = (WLAN_80211_HEAD*)buf;
    
    //PR_DEBUG("=================->%x %x",wbuf->frmae_ctl1,wbuf->frmae_ctl2);
    //not 80211 protocol
    if((wbuf->frmae_ctl1 & 0x3))
        return;
    //type
    switch((wbuf->frmae_ctl1) & 0xc) {
        case 0x8: {
            PR_DEBUG("==========================================================->DATA:%u",len);
            break;
        }
        default: {
            return;
        }
    }

    //dir
    if((wbuf->frmae_ctl2 & 0x3) == 0x1) {
        //station bssid sa da
        if(memcmp(wbuf->addr1,xb_mac,6))
            return;
        print_wlan_mac("sta-bssid:",wbuf->addr1);        
        print_wlan_mac("sta-sa:",wbuf->addr2);        
        print_wlan_mac("sta-da:",wbuf->addr3);
        if( memcmp(wbuf->addr3,"\xff\xff\xff\xff\xff\xff",6) == 0 ) {            
            PR_DEBUG("=================->sta-DATA_broadcast sn %x",(wbuf->seq_ctl)>>4);
        }
    }else if((wbuf->frmae_ctl2 & 0x3) == 0x2) {
        //ap da bssid sa
        if(memcmp(wbuf->addr2,xb_mac,6))
            return;
        print_wlan_mac("ap-da:",wbuf->addr1);        
        print_wlan_mac("ap-bssid:",wbuf->addr2);        
        print_wlan_mac("ap-sa:",wbuf->addr3);
        if(memcmp(wbuf->addr1,"\xff\xff\xff\xff\xff\xff",6) == 0 ) {            
            PR_DEBUG("=================->ap-DATA_broadcast sn %x",(wbuf->seq_ctl)>>4);
        }else if(memcmp(wbuf->addr1,"\x01\x00\x5e",3) == 0) {            
            PR_DEBUG("=================->ap-DATA mutil");
        }
    }
    
}

static int user_parse_80211packet(u_char *buf , u_int len)
{
    //prinf_wlan0_frame(buf,len);
    WLAN_80211_HEAD *wbuf = (WLAN_80211_HEAD*)buf;
    
    //PR_DEBUG("=================->%x %x",wbuf->frmae_ctl1,wbuf->frmae_ctl2);
    //not 80211 protocol
    if((wbuf->frmae_ctl1 & 0x3))
        return -1;
    //type
    switch((wbuf->frmae_ctl1) & 0xc) {
        case 0x8: {
            //PR_DEBUG("=================->DATA");
            break;
        }
        default: {
            return -1;
        }
    }

    //dir
    if((wbuf->frmae_ctl2 & 0x3) == 0x2) {
        //ap da bssid sa
        if(memcmp(wbuf->addr2,junzi_mac,6))
            return -1;
        if(memcmp(wbuf->addr1,"\xff\xff\xff\xff\xff\xff",6) == 0 ) {            
            return 0;
        }else if(memcmp(wbuf->addr1,"\x01\x00\x5e",3) == 0) {      
            return 0;
        }
    }else
        return -1;

    return -1;
    
}


static int realuser_parse_80211packet(u_char *buf , u_int len)
{
    WLAN_80211_HEAD *wbuf = (WLAN_80211_HEAD*)buf;
    if((wbuf->frmae_ctl1 & 0x3))
        return -1;
    //type
    switch((wbuf->frmae_ctl1) & 0xc) {
        case 0x8: {
            break;
        }
        default: {
            return -1;
        }
    }

    //dir
    if((wbuf->frmae_ctl2 & 0x3) == 0x2) {
        //ap da bssid sa
        /*
        if(memcmp(wbuf->addr2,junzi_mac,6))
            return -1;
        */
        if(memcmp(wbuf->addr1,"\xff\xff\xff\xff\xff\xff",6) == 0 ) {            
            return 0;
        }else if(memcmp(wbuf->addr1,"\x01\x00\x5e",3) == 0) {      
            return 0;
        }
    }

    return -1;
}


void processPacket(u_char *argu, const struct pcap_pkthdr* pkthdr, const u_char* packet)
{  
	struct rtl_wifi_header *rh = (struct rtl_wifi_header *)packet;
	unsigned int pk_len = rh->pkt_len;

    	#if 0
	int i = 0;
	printf("\n pkt_len: %d, payload_len = %d\n", pk_len, rh->payload_len);
	printf("RadioTap dump:\n");
	//for(i = 0; i < pk_len; i++) {
	for(i = 0; i < pk_len; i++) {
		printf("[%02x]", rh->data[i]);
		if(((i%10 == 0) && (i != 0)))
			printf("\n");
	}
	#endif

    if(pk_len > 0) {
#if 1
        //mimo dont handle
        if(rh->data[0] != 0xff) {
            if(s_pSnifferCall && realuser_parse_80211packet(rh->data,pk_len) == 0) {
	            s_pSnifferCall(rh->data,pk_len,0);  
	        }
	    
        }
        
#else
        parse_80211packet(rh->data,pk_len);    
#endif
    }

    
}

// 设置WIFI的sniffer抓包状态
OPERATE_RET tuya_8197_wifi_sniffer_set(IN CONST BOOL_T en,IN CONST SNIFFER_CALLBACK cb)
{
	return OPRT_OK;
}

OPERATE_RET hwl_wifi_if_connect_internet(BOOL_T *status)
{
    *status = TRUE;
    return OPRT_OK;
}


// 获取WIFI的MAC地址
#define WF_MAC_ETHER_STR    "HWaddr "
OPERATE_RET tuya_8197_wifi_get_mac(IN CONST WF_IF_E wf,INOUT NW_MAC_S *mac)
{
    FILE *pp = popen("ifconfig "WLAN_DEV, "r");
    if(pp == NULL)
       return OPRT_COM_ERROR;

    char tmp[256];
    memset(tmp, 0, sizeof(tmp));
    while (fgets(tmp, sizeof(tmp), pp) != NULL)
    {
        char *pMACStart = strstr(tmp, WF_MAC_ETHER_STR);
        if(pMACStart != NULL)
        {
            int x1,x2,x3,x4,x5,x6;
            sscanf(pMACStart + strlen(WF_MAC_ETHER_STR), "%x:%x:%x:%x:%x:%x",&x1,&x2,&x3,&x4,&x5,&x6);
            mac->mac[0] = x1 & 0xFF;
            mac->mac[1] = x2 & 0xFF;
            mac->mac[2] = x3 & 0xFF;
            mac->mac[3] = x4 & 0xFF;
            mac->mac[4] = x5 & 0xFF;
            mac->mac[5] = x6 & 0xFF;

            break;
        }
    }
    pclose(pp);

    PR_DEBUG("WIFI Get MAC %02X-%02X-%02X-%02X-%02X-%02X", mac->mac[0],mac->mac[1],mac->mac[2],mac->mac[3],mac->mac[4],mac->mac[5]);
    return OPRT_OK;
}

// 当前无需实现
OPERATE_RET tuya_8197_wifi_set_mac(IN CONST WF_IF_E wf,IN CONST NW_MAC_S *mac)
{
    return OPRT_OK;
}

// 设置当前WIFI工作模式
int tuya_8197_wifi_set_work_mode(IN CONST WF_WK_MD_E mode)
{
    char tmpCmd[MAX_CMD_BUF] = {0};

	//snprintf(tmpCmd,MAX_CMD_BUF,"flash set %s WLAN_DISABLED 0", WLAN_DEV);
	//linux_exec_cmd(tmpCmd,NULL,0);

	switch (mode) {
		case WWM_LOWPOWER:
		    //linux系统不关心低功耗
		    break;
		case WWM_SNIFFER:
    		/*
    		snprintf(tmpCmd,MAX_CMD_BUF,"iwconfig %s mode monitor",WLAN_DEV);
    		//linux_exec_cmd(tmpCmd,NULL,0);
    		*/
		    break;

		case WWM_STATION:
    		/*
    		memset(tmpCmd,MAX_CMD_BUF,0);
    		snprintf(tmpCmd,MAX_CMD_BUF, "iwconfig %s mode managed",WLAN_DEV);
    		//linux_exec_cmd(tmpCmd,NULL,0);

    		//station
    		memset(tmpCmd,0,MAX_CMD_BUF);
    		snprintf(tmpCmd,MAX_CMD_BUF,"flash set %s MODE 1",WLAN_DEV);
    		linux_exec_cmd(tmpCmd,NULL,0);
    		linux_exec_cmd(NETWORK_RESTART,NULL,0);
    		*/
            
    		break;

		case WWM_SOFTAP:
    		#if 0		
    		moni = FALSE;
    		
    		snprintf(tmpCmd, 100, "iwconfig %s mode master",WLAN_DEV);
    		linux_exec_cmd(tmpCmd,NULL,0);
    		memset(tmpCmd,0,100);
    		snprintf(tmpCmd, 100, "flash set %s MODE 0",WLAN_DEV);
    		linux_exec_cmd(tmpCmd,NULL,0);
    		linux_exec_cmd(NETWORK_RESTART);    		
    		
    		#endif
    		break;
		case WWM_STATIONAP:
		    break;
		default:
		    break;
	}

	PR_DEBUG("WIFI Set Mode:%d", mode);
	return OPRT_OK;
}

// 获取当前WIFI工作模式
OPERATE_RET tuya_8197_wifi_get_work_mode(OUT WF_WK_MD_E *mode)
{
    BOOL_T ap_mode;
    hwl_bnw_8197wlan_get_mode(&ap_mode);
    if(ap_mode)        
        *mode = WWM_SOFTAP;
    else
        *mode = WWM_STATION;
    
    /*
    char tmp[256] = {0};
   	char scan_mode[10] = {0};
	FILE *pp = popen("iwconfig "WLAN_DEV, "r");

	*mode = WWM_STATION;

	if(pp == NULL)
		return OPRT_OK;

	while (fgets(tmp, sizeof(tmp), pp) != NULL) {
		char *pModeStart = strstr(tmp, "Mode:");
		if(pModeStart != NULL) {
			sscanf(pModeStart + strlen("Mode:"), "%s ", scan_mode);
			break;
		}
	}
	pclose(pp);

	if(strncasecmp(scan_mode, "Managed", strlen("Managed")) == 0)
		*mode = WWM_STATION;
	if(strncasecmp(scan_mode, "Master", strlen("Master")) == 0)
		*mode = WWM_SOFTAP;
	if(strncasecmp(scan_mode, "Monitor", strlen("Monitor")) == 0)
		*mode = WWM_SNIFFER;
    */
	//PR_DEBUG("WIFI Get Mode:%d", *mode);
	return OPRT_OK;
}

// 断开当前WIFI网络的连接
OPERATE_RET tuya_8197_wifi_station_disconnect(VOID)
{
    PR_DEBUG("Disconnect WIFI Conn");
	return 0;
}

// 获取当前WIFI联网的RSSI
OPERATE_RET tuya_8197_wifi_station_get_conn_ap_rssi(OUT SCHAR_T *rssi)
{
    *rssi = 0;
    
    char buf[MAX_R_BUF] = {0};
    //linux_exec_cmd("cat /proc/wlan0/sta_info|grep rssi", buf, MAX_R_BUF);

    char *op_ptr = &buf[0];
    op_ptr = strstr(op_ptr,"rssi");
    if(NULL == op_ptr) {
        printf("get wifi rssi failed\n");
        return OPRT_COM_ERROR;
    }

    int value;
    sscanf(op_ptr + strlen("rssi: "),"%d",&value);

    *rssi = value;    

    PR_DEBUG("Get Conn AP RSSI:%d", *rssi);
    return OPRT_OK;
}

// 获取当前WIFI AP的MAC
OPERATE_RET tuya_8197_wifi_station_get_ap_mac(INOUT NW_MAC_S *mac)
{
    char buf[MAX_R_BUF] = {0};
    //linux_exec_cmd("cat /proc/wlan0/sta_info|grep hwaddr", buf, MAX_R_BUF);

    char *op_ptr = &buf[0];
    op_ptr = strstr(op_ptr,"hwaddr");
    if(NULL == op_ptr) {
       printf("get wifi connect hwaddr failed\n");
       return OPRT_COM_ERROR;
    }

    UINT_T tmp_mac[6] = {0};
    sscanf(op_ptr + strlen("hwaddr: "),"%02x%02x%02x%02x%02x%02x", \
            &tmp_mac[0],&tmp_mac[1],&tmp_mac[2],&tmp_mac[3],&tmp_mac[4],&tmp_mac[5]);

    mac->mac[0] = tmp_mac[0];    
    mac->mac[1] = tmp_mac[1];
    mac->mac[2] = tmp_mac[2];
    mac->mac[3] = tmp_mac[3];
    mac->mac[4] = tmp_mac[4];
    mac->mac[5] = tmp_mac[5];

    PR_DEBUG("AP MAC %02X-%02X-%02X-%02X-%02X-%02X", mac->mac[0],mac->mac[1],mac->mac[2],
        mac->mac[3],mac->mac[4],mac->mac[5]);
    return OPRT_OK;
}

// 获取当前WIFI联网状态
//高频接口    
OPERATE_RET tuya_8197_wifi_station_get_status(OUT WF_STATION_STAT_E *stat)
{              
    return OPRT_OK;
}

// AP配网模式下开启热点
OPERATE_RET tuya_8197_wifi_ap_start(IN CONST WF_AP_CFG_IF_S *cfg)
{
    return OPRT_OK;
}

// AP配网模式下停止热点
OPERATE_RET tuya_8197_wifi_ap_stop(VOID)
{    
    exec_cmd("ifconfig wlan0 down");
    PR_DEBUG("Stop Ap Mode");
    return OPRT_OK;
}

OPERATE_RET tuya_8197_wifi_set_country_code(const COUNTRY_CODE_E ccode)
{
    return OPRT_OK;
}

OPERATE_RET tuya_8197_wifi_lowpower_enable(VOID)
{
    return OPRT_OK;
}

OPERATE_RET tuya_8197_wifi_lowpower_disable(VOID)
{
    return OPRT_OK;
}

// 获取某个AP的RSSI
OPERATE_RET tuya_8197_wifi_get_ap_rssi(IN CONST CHAR_T *ap_name,OUT INT_T *rssi)
{
    *rssi = 0;

    PR_DEBUG("Get %s ,RSSI:%d",ap_name ,*rssi);
    return OPRT_OK;
}


STATIC VOID hwl_bnw_8197wlan_set_mode(BOOL_T apmode)
{
}

STATIC VOID hwl_bnw_8197wlan_get_mode(BOOL_T *apmode)
{
    *apmode = TRUE;
}

STATIC VOID hwl_bnw_8197wlan_iwset_country(VOID)
{    
    ;
}

int tuya_8197_wifi_close_concurrent_ap(void)
{
    return 0;
}

int tuya_8197_wifi_send_mgnt(const UCHAR_T *buf, const UCHAR_T len)
{
    return 0;
}

int tuya_8197_wifi_register_recv_mgnt_callback(CONST BOOL_T enable, CONST WIFI_REV_MGNT_CB recv_cb)
{
    return 0;
}

int tuya_8197_wifi_get_bssid(uint8_t mac[6])
{
    return 0;
}

int tuya_8197_wifi_set_wifi_lp_mode(CONST BOOL_T en, CONST UCHAR_T dtim)
{
    return 0;
}

OPERATE_RET tuya_8197_wifi_get_ip(IN CONST WF_IF_E wf,OUT NW_IP_S *ip)
{
    return 0;
}

STATIC TUYA_OS_WIFI_INTF tuya_8197_wifi_intfs = {
    .all_ap_scan        = tuya_8197_wifi_all_ap_scan, 
    .assign_ap_scan     = tuya_8197_wifi_assign_ap_scan,
    .release_ap         = tuya_8197_wifi_release_ap,
    .set_cur_channel    = tuya_8197_wifi_set_cur_channel,
    .get_cur_channel    = tuya_8197_wifi_get_cur_channel,
    .sniffer_set        = tuya_8197_wifi_sniffer_set,
    .get_ip             = tuya_8197_wifi_get_ip,
    .set_mac            = tuya_8197_wifi_set_mac,
    .get_mac            = tuya_8197_wifi_get_mac,
    .set_work_mode      = tuya_8197_wifi_set_work_mode,
    .get_work_mode      = tuya_8197_wifi_get_work_mode,
    .ap_start           = tuya_8197_wifi_ap_start,
    .ap_stop            = tuya_8197_wifi_ap_stop,
    
    //.get_connected_ap_info_v2   = tuya_os_adapt_wifi_get_connected_ap_info_v2,
    //.fast_station_connect_v2    = tuya_os_adapt_wifi_fast_station_connect_v2,
    .station_connect            = tuya_8197_wifi_station_connect,
    .station_disconnect         = tuya_8197_wifi_station_disconnect,
    .station_get_conn_ap_rssi   = tuya_8197_wifi_station_get_conn_ap_rssi,
    .get_bssid                  = tuya_8197_wifi_get_bssid,
    
    .station_get_status         = tuya_8197_wifi_station_get_status,
    .set_country_code           = tuya_8197_wifi_set_country_code,
    .send_mgnt                  = tuya_8197_wifi_send_mgnt,
    .register_recv_mgnt_callback= tuya_8197_wifi_register_recv_mgnt_callback,
    .set_lp_mode                = tuya_8197_wifi_set_wifi_lp_mode,
};

OPERATE_RET tuya_register_wifi_intf(void)
{
    return tuya_os_adapt_reg_intf(INTF_WIFI, (void*)&tuya_8197_wifi_intfs);
}

