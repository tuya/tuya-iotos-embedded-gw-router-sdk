#ifndef __COMPONENT_TUYA_ROUTE_SVC_H__
#define __COMPONENT_TUYA_ROUTE_SVC_H__

#include "tuya_cloud_types.h"
#include "tuya_cloud_com_defs.h"
#include "tuya_cloud_error_code.h"
#include "uni_log.h"
#include "tuya_iot_internal_api.h"
//#include "tuya_os_adapter.h"

#define TY_ROUTE_LOGIN_STR_MAX      64 // ssid: 0 - 32, pwd: 8 - 63
#define TY_ROUTE_DEV_NAME_MAX       64
#define TY_ROUTE_MAC_STR_LEN        18
#define WIFI_SSID_LEN				32
#define WIFI_PASSWD_LEN 65

#define AGENT_EXT_PRO_REQ 193
#define AGENT_EXT_PRO_RESP 193


typedef BYTE_T TY_WIFI_TYPE;
#define TY_WIFI_TYPE_2_4G           1
#define TY_WIFI_TYPE_5G             2

typedef BYTE_T TY_WIFI_SIG_STRENGTH;
#define TY_WIFI_SIG_LOW             1
#define TY_WIFI_SIG_MID             2
#define TY_WIFI_SIG_HIGH            3


//cmd list
typedef enum {
    TY_ROUTE_CMD_GET_ONLINE_LIST = 1,   //获取中继器下在线设备列表
    TY_ROUTE_CMD_GET_BLACK_LIST = 2,    //获取中继器下设备黑名单列表
    TY_ROUTE_CMD_GET_WIFI_LIST = 3,     //获取中继器可连接的WIFI列表
    TY_ROUTE_CMD_INVALD                 //无效命令
} TY_ROUTE_CMD_E;

typedef enum {
    TY_STA_CMD_ALLOW_NET = 1,
    TY_STA_CMD_SPEED_LIMIT = 2,
    TY_STA_CMD_UP_LIMIT = 3,
    TY_STA_CMD_DOWN_LIMIT = 4,
    TY_STA_CMD_GET_ALL_CONFIG = 5,
    TTY_STA_CMD_INVALD
        
} TY_ROUTE_STA_CMD_E;

typedef struct {
    BOOL_T allow;
    BOOL_T limit; 
    UINT_T up_limit; 
    UINT_T down_limit; 

} TUYA_ROUTE_STA_CONF_S;


//中继器可选WI-FI信号列表
typedef struct {
    CHAR_T ssid[TY_ROUTE_LOGIN_STR_MAX];
    BOOL_T b_encrypted;
    TY_WIFI_SIG_STRENGTH signal_strength; // 1-2.4G, 2-5G

}TUYA_ROUTE_WIFI_LIST_S;

//中继器可选WI-FI信号列表
typedef struct {
    TY_WIFI_TYPE wifi_types;
    CHAR_T ssid[TY_ROUTE_LOGIN_STR_MAX];
    CHAR_T pwd[TY_ROUTE_LOGIN_STR_MAX];

}TUYA_ROUTE_HOTSPOT_S;


//中继器下设备列表
typedef struct {
    CHAR_T dev_name[TY_ROUTE_DEV_NAME_MAX];
    CHAR_T mac[TY_ROUTE_MAC_STR_LEN];
    TY_WIFI_TYPE wifi_types; // 1-2.4G, 2-5G

}TUYA_ROUTE_DEV_LIST_S;


typedef enum {
    TY_ROUTE_PWD_INVALID = 0,
    TY_ROUTE_PWD_2_4G = 1,
    TY_ROUTE_PWD_5G = 2,
} TUYA_ROUTE_PWD_E;

typedef enum {
    BRAND_CONN_TYPE_PPPOE = 0,
    BRAND_CONN_TYPE_DHCP,
    BRAND_CONN_TYPE_STATIC_IP,
    BRAND_CONN_TYPE_WIRED_REPEATER,
    BRAND_CONN_TYPE_WIFI_REPEATER,
    BRAND_CONN_TYPE_INVALID,
} BRAND_CONN_TYPE_T;

typedef struct {
    CHAR_T account[WIFI_SSID_LEN + 1];
    CHAR_T pwd[WIFI_PASSWD_LEN + 1];
} PPPOE_INFO_T;

typedef struct {
    CHAR_T ap_ssid[WIFI_SSID_LEN+1]; // ap ssid info
    CHAR_T ap_passwd[WIFI_PASSWD_LEN+1]; // ap passwd info
} WIFI_INFO_T;

typedef struct {
    char ip[16];    /* ip addr:  xxx.xxx.xxx.xxx  */
    char mask[16];  /* net mask: xxx.xxx.xxx.xxx  */
    char gw[16];    /* gateway:  xxx.xxx.xxx.xxx  */
    char primary_dns[16];
    char secondary_dns[16];;
} STATIC_IP_T;

typedef struct {
    BRAND_CONN_TYPE_T brand_conn_type;
    PPPOE_INFO_T pppoe_info;
    STATIC_IP_T  static_ip_info;
    WIFI_INFO_T wifi_info;
} BRAND_CONN_SETTING_INFO;

typedef VOID (*TY_ROUTE_CMD_HANDLE_CB)(IN CONST TY_ROUTE_CMD_E cmd);
typedef VOID (*TY_ROUTE_GET_SOURCE_CB)(VOID);
typedef VOID (*TY_ROUTE_SET_SOURCE_CB)(IN CONST CHAR_T *ssid, IN CONST CHAR_T *pwd);
typedef VOID (*TY_ROUTE_GET_HOTSPOT_CB)(VOID);
typedef VOID (*TY_ROUTE_SET_HOTSPOT_CB)(IN CONST TUYA_ROUTE_HOTSPOT_S *p_hotspot, IN CONST USHORT_T num);
typedef VOID (*TY_ROUTE_STA_CMD_CB)(IN CONST TY_ROUTE_STA_CMD_E cmd, IN CONST CHAR_T *mac, IN CONST UINT_T value);

typedef VOID (*TY_ROUTE_CMD_CB)(IN CONST TY_ROUTE_CMD_E cmd);
typedef VOID (*TY_ROUTE_QUERY_PWD_CB)(IN CONST TUYA_ROUTE_PWD_E type);
typedef VOID (*TY_ROUTE_SET_PWD_CB)(IN CONST TUYA_ROUTE_PWD_E type, IN CONST CHAR_T *pwd);

typedef VOID (*TY_ROUTE_GET_CONN_TYPE_CB)(VOID);
typedef VOID (*TY_ROUTE_SET_CONN_TYPE_CB)(IN CONST BRAND_CONN_SETTING_INFO *setting);


typedef struct {
    TY_ROUTE_CMD_HANDLE_CB cmd_handle_cb;
    TY_ROUTE_GET_SOURCE_CB get_source_cb;
    TY_ROUTE_SET_SOURCE_CB set_source_cb;
    TY_ROUTE_GET_HOTSPOT_CB get_hotspot_cb;
    TY_ROUTE_SET_HOTSPOT_CB set_hotspot_cb;
	
    TY_ROUTE_QUERY_PWD_CB   route_query_pwd_cb;
    TY_ROUTE_SET_PWD_CB     route_set_pwd_cb;

    TY_ROUTE_GET_CONN_TYPE_CB route_get_brand_conn_type_cb;
    TY_ROUTE_SET_CONN_TYPE_CB route_set_brand_conn_type_cb;
}TUYA_ROUTE_CBS_S;

typedef struct {
    TY_ROUTE_STA_CMD_CB     sta_cmd_cb;
}TUYA_ROUTE_STA_CBS_S;


#ifdef __cplusplus
extern "C" {
#endif

// 上报连接在中继器下设备的信息
OPERATE_RET tuya_route_rept_online_list(IN CONST USHORT_T dev_count, 
                                        IN CONST TUYA_ROUTE_DEV_LIST_S *p_list);
// 上报中继器可连接的WI-FI列表
OPERATE_RET tuya_route_rept_wifi_list(IN CONST USHORT_T dev_count, 
                                      IN CONST TUYA_ROUTE_WIFI_LIST_S *p_list);
// 上报中继器连接的WI-FI的ssid/passwd
OPERATE_RET tuya_route_rept_source(IN CONST CHAR_T *ssid, IN CONST CHAR_T *pwd);

// 上报中继器自身热点2.4G/5G ssid/pwd
OPERATE_RET tuya_route_rept_hotspot(IN CONST TUYA_ROUTE_HOTSPOT_S *p_hotspot, IN CONST USHORT_T num);


OPERATE_RET tuya_route_rept_sta_allow_net(IN CONST CHAR_T *mac, 
                                          IN CONST BOOL_T allow, 
                                          IN CONST UINT_T sta_dpid);
OPERATE_RET tuya_route_rept_sta_limit(IN CONST CHAR_T *mac, 
                                      IN CONST BOOL_T limit, 
                                      IN CONST UINT_T sta_dpid);
OPERATE_RET tuya_route_rept_sta_up_limit(IN CONST CHAR_T *mac, 
                                         IN CONST UINT_T limit, 
                                         IN CONST UINT_T sta_dpid);
OPERATE_RET tuya_route_rept_sta_down_limit(IN CONST CHAR_T *mac, 
                                           IN CONST UINT_T limit, 
                                           IN CONST UINT_T sta_dpid);
OPERATE_RET tuya_route_rept_sta_all(IN CONST CHAR_T *mac, 
                                    IN CONST TUYA_ROUTE_STA_CONF_S *config, 
                                    IN CONST UINT_T sta_dpid);                                                 
OPERATE_RET tuya_route_sta_data_parse(IN CONST CHAR_T *data);

OPERATE_RET tuya_route_service_init(IN CONST TUYA_ROUTE_CBS_S *p_route_cbs, 
                                    IN CONST TUYA_ROUTE_STA_CBS_S *p_sta_cbs);


OPERATE_RET tuya_route_rept_pwd(IN CONST TUYA_ROUTE_PWD_E type, IN CONST CHAR_T *pwd);

OPERATE_RET iot_app_ext_pro_conn_type_response(CHAR_T error_code, CONST CHAR_T *data[], UCHAR_T data_num);
OPERATE_RET iot_app_ext_pro_conn_setting_response(CHAR_T error_code);

BOOL_T get_route_net_stat(VOID);
VOID set_route_net_stat(BOOL_T online);

#ifdef __cplusplus
} // extern "C"
#endif

#endif // __COMPONENT_TUYA_ROUTE_SVC_H__
